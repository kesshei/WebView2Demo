---
description: "Getting started with WebView2 for Win32 apps doc"
languages: 
  - cpp
page_type: sample
products: 
  - microsoft-edge
urlFragment: webview2-win32-getting-started
---
# Getting Started with WebView2 for Win32 apps

This sample relates to the [Getting started with WebView2 for Win32 apps](https://docs.microsoft.com/microsoft-edge/webview2/gettingstarted/win32) doc.

![sample snapshot](https://raw.githubusercontent.com/MicrosoftDocs/edge-developer/master/microsoft-edge/webview2/media/bing-window.png)