let text = "Load Javascript successfully!";
let newNode = document.createElement("h1");
newNode.innerText = text;
document.body.appendChild(newNode);